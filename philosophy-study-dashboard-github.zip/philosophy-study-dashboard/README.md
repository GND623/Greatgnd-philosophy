# 哲学学习仪表盘

一个可直接运行和上传 GitHub 的 React/Vite 项目，用于每日哲学概念训练、答题记录、打卡进度和纠错 Prompt 复制。

## 本地运行

```bash
npm install
npm run dev
```

## 构建发布

```bash
npm run build
```

构建后的静态文件会生成在 `dist/` 目录。

## 项目结构

```text
philosophy-study-dashboard/
├── index.html
├── package.json
├── vite.config.js
├── src/
│   ├── App.jsx
│   ├── main.jsx
│   ├── index.css
│   ├── components/ui/
│   │   ├── button.jsx
│   │   ├── card.jsx
│   │   └── progress.jsx
│   └── lib/utils.js
└── README.md
```

## 后续扩展

每日题目集中写在 `src/App.jsx` 的 `dailySets` 对象中。继续增加 Day 3、Day 4 即可扩展题库。
