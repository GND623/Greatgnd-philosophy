import React from "react";
import ReactDOM from "react-dom/client";
import PhilosophyStudyDashboard from "./App.jsx";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <PhilosophyStudyDashboard />
  </React.StrictMode>
);
