import React, { useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { CheckCircle2, Circle, Copy, CalendarDays } from "lucide-react";
import { motion } from "framer-motion";

const dailySets = {
  "Day 1": {
    question1: "为什么柏拉图的 Form 与亚里士多德的 Form 有根本差异？",
    question2: "为什么 identity 无法完全替代 subject？",
    concepts: [
      ["Form", "柏拉图处为独立理念；亚里士多德处为事物内部本质结构。"],
      ["Subject", "不仅是自我，而是行动、反思与承担责任的位置。"],
    ],
  },
  "Day 2": {
    question1: "为什么康德认为人只能认识 phenomenon，而不能认识 noumenon？",
    question2: "为什么后人类理论会修正近代主体概念？",
    concepts: [
      ["Phenomenon", "经主体认知结构组织后的经验对象。"],
      ["Noumenon", "脱离认识结构的物自体。"],
    ],
  },
};

export default function PhilosophyStudyDashboard() {
  const [currentDay, setCurrentDay] = useState("Day 1");
  const [done, setDone] = useState([]);
  const [answer, setAnswer] = useState("");
  const [reference, setReference] = useState("");

  const data = dailySets[currentDay];

  const tasks = [
    "阅读概念简述并区分相关概念",
    "完成经典哲学问题短答",
    "完成当代理论问题短答",
  ];

  const progress = useMemo(() => Math.round((done.length / tasks.length) * 100), [done, tasks.length]);

  const toggle = (idx) => {
    setDone((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  const prompt = `请作为严格的哲学导师，对我的答案进行概念精度、逻辑结构与哲学史关系上的纠错，并给出标准参考答案。\n\n问题1：${data.question1}\n\n问题2：${data.question2}\n\n我的答案：\n${answer}`;

  const copyPrompt = async () => {
    try {
      await navigator.clipboard.writeText(prompt);
      alert("Prompt 已复制");
    } catch (error) {
      alert("复制失败，请手动复制文本。浏览器可能限制了剪贴板权限。");
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 p-4 text-neutral-100 md:p-8">
      <div className="mx-auto max-w-5xl space-y-6">
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="rounded-3xl border-neutral-800 bg-neutral-900 shadow-xl">
            <CardContent className="p-6 md:p-8">
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h1 className="text-3xl font-semibold tracking-tight md:text-4xl">哲学学习仪表盘</h1>
                  <p className="mt-2 text-neutral-400">每天 1 小时 · 概念精度训练</p>
                </div>
                <CalendarDays className="h-8 w-8 shrink-0 text-emerald-300" />
              </div>

              <div className="mt-6 flex flex-wrap gap-2">
                {Object.keys(dailySets).map((d) => (
                  <Button
                    key={d}
                    onClick={() => {
                      setCurrentDay(d);
                      setDone([]);
                    }}
                    variant={currentDay === d ? "default" : "secondary"}
                    className="rounded-2xl"
                  >
                    {d}
                  </Button>
                ))}
              </div>

              <div className="mt-6">
                <div className="mb-2 flex justify-between text-sm text-neutral-400">
                  <span>今日完成度</span>
                  <span>{progress}%</span>
                </div>
                <Progress value={progress} className="h-3" />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card className="rounded-3xl border-neutral-800 bg-neutral-900 shadow-xl">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold">今日任务</h2>

              <div className="mt-5 space-y-3">
                {tasks.map((task, idx) => (
                  <button
                    key={task}
                    onClick={() => toggle(idx)}
                    className="w-full rounded-2xl border border-neutral-800 bg-neutral-950/60 p-4 text-left transition hover:border-emerald-400/60"
                  >
                    <div className="flex items-center gap-3">
                      {done.includes(idx) ? (
                        <CheckCircle2 className="h-5 w-5 text-emerald-300" />
                      ) : (
                        <Circle className="h-5 w-5 text-neutral-500" />
                      )}
                      <span>{task}</span>
                    </div>
                  </button>
                ))}
              </div>

              <div className="mt-6 rounded-2xl border border-neutral-800 bg-neutral-950/60 p-4">
                <h3 className="text-lg font-semibold text-emerald-300">今日问题</h3>
                <p className="mt-3">① {data.question1}</p>
                <p className="mt-3">② {data.question2}</p>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-neutral-800 bg-neutral-900 shadow-xl">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold">概念简述</h2>

              <div className="mt-5 space-y-3">
                {data.concepts.map(([term, desc]) => (
                  <div
                    key={term}
                    className="rounded-2xl border border-neutral-800 bg-neutral-950/60 p-4"
                  >
                    <p className="font-semibold text-emerald-300">{term}</p>
                    <p className="mt-1 text-sm text-neutral-300">{desc}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card className="rounded-3xl border-neutral-800 bg-neutral-900 shadow-xl">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold">答题记录</h2>

              <textarea
                value={answer}
                onChange={(e) => setAnswer(e.target.value)}
                placeholder="在这里写今天的答案……"
                className="mt-5 min-h-[240px] w-full rounded-2xl border border-neutral-800 bg-neutral-950/60 p-4 text-neutral-100 outline-none focus:border-emerald-400/70"
              />

              <div className="mt-4 flex gap-3">
                <Button className="rounded-2xl" onClick={copyPrompt}>
                  <Copy className="mr-2 h-4 w-4" />复制纠错 Prompt
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="rounded-3xl border-neutral-800 bg-neutral-900 shadow-xl">
            <CardContent className="p-6">
              <h2 className="text-2xl font-semibold">标准答案对照区</h2>

              <textarea
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                placeholder="把纠错后的标准答案粘贴到这里，方便反复练习……"
                className="mt-5 min-h-[240px] w-full rounded-2xl border border-neutral-800 bg-neutral-950/60 p-4 text-neutral-100 outline-none focus:border-emerald-400/70"
              />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
