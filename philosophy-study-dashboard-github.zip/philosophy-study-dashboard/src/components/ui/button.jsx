import React from "react";
import { cn } from "@/lib/utils";

const variants = {
  default: "bg-neutral-100 text-neutral-950 hover:bg-neutral-200",
  secondary: "bg-neutral-800 text-neutral-100 hover:bg-neutral-700",
};

export function Button({ className, variant = "default", ...props }) {
  return (
    <button
      className={cn(
        "inline-flex items-center justify-center whitespace-nowrap px-4 py-2 text-sm font-medium transition disabled:pointer-events-none disabled:opacity-50",
        variants[variant] || variants.default,
        className
      )}
      {...props}
    />
  );
}
