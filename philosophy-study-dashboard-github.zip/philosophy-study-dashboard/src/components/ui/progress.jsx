import React from "react";
import { cn } from "@/lib/utils";

export function Progress({ value = 0, className }) {
  const safeValue = Math.max(0, Math.min(100, value));

  return (
    <div className={cn("relative overflow-hidden rounded-full bg-neutral-800", className)}>
      <div
        className="h-full rounded-full bg-emerald-300 transition-all"
        style={{ width: `${safeValue}%` }}
      />
    </div>
  );
}
